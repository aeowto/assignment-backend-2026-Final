(function () {
  var localRoot = "http://127.0.0.1:8000";
  window.API_ROOT = window.API_ROOT || localRoot;
  window.API_BASE = window.API_BASE || localRoot + "/api/codex_live_002";
})();

var state = {
  posts: [],
  comments: [],
  likes: [],
  page: 0,
  pageSize: 4,
  total: 0,
  loading: false,
  done: false,
  likedKey: "travel-feed-liked-posts"
};

function $(id) {
  return document.getElementById(id);
}

function setApiState(text) {
  $("apiState").textContent = text;
}

function request(path, options) {
  return fetch(API_BASE + path, options || {})
    .then(function (res) {
      return res.json().then(function (body) {
        if (!res.ok || body.success === false) {
          throw new Error(body.message || body.detail || "请求失败");
        }
        return body.data;
      });
    });
}

function escapeHtml(value) {
  return String(value == null ? "" : value).replace(/[&<>"']/g, function (ch) {
    return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[ch];
  });
}

function itemData(item) {
  return Object.assign({ id: item.id }, item.data || {});
}

function readLikedPosts() {
  try {
    return JSON.parse(localStorage.getItem(state.likedKey) || "[]");
  } catch (error) {
    return [];
  }
}

function writeLikedPosts(ids) {
  localStorage.setItem(state.likedKey, JSON.stringify(ids));
}

function commentsFor(postId) {
  return state.comments.filter(function (comment) {
    return comment.postId === postId;
  });
}

function likesFor(postId) {
  return state.likes.filter(function (like) {
    return like.postId === postId;
  });
}

function formatImages(images) {
  var list = Array.isArray(images) ? images : [];
  if (!list.length) return "";
  return '<div class="image-grid">' + list.map(function (src) {
    return '<img src="' + escapeHtml(src) + '" alt="旅行照片">';
  }).join("") + '</div>';
}

function formatTags(tags) {
  var list = Array.isArray(tags) ? tags : [];
  if (!list.length) return "";
  return '<div class="tag-row">' + list.map(function (tag) {
    return '<span class="tag"># ' + escapeHtml(tag) + '</span>';
  }).join("") + '</div>';
}

function renderPost(post) {
  var likedIds = readLikedPosts();
  var liked = likedIds.indexOf(post.id) >= 0;
  var comments = commentsFor(post.id);
  var likes = likesFor(post.id);
  return '<article class="post-card" data-post-id="' + escapeHtml(post.id) + '">' +
    '<div class="post-main">' +
      '<div class="post-author">' +
        '<div class="mini-avatar">' + escapeHtml((post.author || "旅").slice(0, 1)) + '</div>' +
        '<div><b>' + escapeHtml(post.author || "旅行记录") + '</b>' +
        '<span class="meta">' + escapeHtml(post.place || "未知地点") + ' · ' + escapeHtml(post.date || "") + '</span></div>' +
      '</div>' +
      '<h3 class="post-title">' + escapeHtml(post.title || "未命名旅行") + '</h3>' +
      '<p class="post-text">' + escapeHtml(post.content || "") + '</p>' +
      formatImages(post.images) +
      formatTags(post.tags) +
      '<div class="post-actions">' +
        '<button class="action-button like-button ' + (liked ? "is-liked" : "") + '" type="button" data-post-id="' + escapeHtml(post.id) + '">' +
          (liked ? "已点赞" : "点赞") + ' · ' + likes.length +
        '</button>' +
        '<button class="action-button comment-focus" type="button" data-post-id="' + escapeHtml(post.id) + '">评论 · ' + comments.length + '</button>' +
      '</div>' +
    '</div>' +
    '<div class="comments">' +
      '<div class="comment-list">' + (comments.length ? comments.map(function (comment) {
        return '<div class="comment"><b>' + escapeHtml(comment.nickname || "访客") + '：</b>' + escapeHtml(comment.content || "") + '</div>';
      }).join("") : '<p class="empty">还没有评论，来补一条旅行建议。</p>') + '</div>' +
      '<form class="comment-form" data-post-id="' + escapeHtml(post.id) + '">' +
        '<input name="nickname" maxlength="18" value="访客">' +
        '<input name="content" maxlength="160" placeholder="写一条评论，例如路线建议、避坑提醒或想去打卡。">' +
        '<button type="submit">发送</button>' +
      '</form>' +
    '</div>' +
  '</article>';
}

function renderStats() {
  $("postTotal").textContent = state.total || state.posts.length;
  $("likeTotal").textContent = state.likes.length;
  $("commentTotal").textContent = state.comments.length;

  var placeCounts = {};
  state.posts.forEach(function (post) {
    var place = post.place || "未知地点";
    placeCounts[place] = (placeCounts[place] || 0) + 1;
  });
  var places = Object.keys(placeCounts).sort(function (a, b) {
    return placeCounts[b] - placeCounts[a];
  });
  $("placeList").innerHTML = places.length ? places.map(function (place) {
    return '<div class="place-item"><b>' + escapeHtml(place) + '</b><span>' + placeCounts[place] + ' 条</span></div>';
  }).join("") : '<p class="empty">加载旅行地点中。</p>';
}

function renderFeed() {
  $("feedList").innerHTML = state.posts.length ? state.posts.map(renderPost).join("") : '<p class="empty">还没有旅行记录。</p>';
  renderStats();
  if (state.done) {
    $("loadMoreSentinel").textContent = "已经到底了";
  } else if (state.loading) {
    $("loadMoreSentinel").textContent = "正在加载...";
  } else {
    $("loadMoreSentinel").textContent = "向下滚动加载更多";
  }
}

function mergeById(list, incoming) {
  var seen = {};
  list.forEach(function (item) {
    seen[item.id] = true;
  });
  incoming.forEach(function (item) {
    if (!seen[item.id]) {
      seen[item.id] = true;
      list.push(item);
    }
  });
}

function loadSideData() {
  return Promise.all([
    request("/comments?page=1&pageSize=50"),
    request("/likes?page=1&pageSize=50")
  ]).then(function (results) {
    state.comments = (results[0].items || []).map(itemData);
    state.likes = (results[1].items || []).map(itemData);
  });
}

function loadNextPage(reset) {
  if (state.loading) return Promise.resolve();
  if (!reset && state.done) return Promise.resolve();
  state.loading = true;
  if (reset) {
    state.page = 0;
    state.posts = [];
    state.done = false;
  }
  renderFeed();
  var nextPage = state.page + 1;
  return Promise.all([
    request("/posts?page=" + nextPage + "&pageSize=" + state.pageSize),
    loadSideData()
  ]).then(function (results) {
    var pageData = results[0];
    state.page = pageData.page;
    state.total = pageData.total || 0;
    mergeById(state.posts, (pageData.items || []).map(itemData));
    state.done = state.posts.length >= state.total;
    setApiState("已连接，" + state.posts.length + " / " + state.total);
  }).catch(function (error) {
    setApiState("错误：" + error.message);
  }).finally(function () {
    state.loading = false;
    renderFeed();
  });
}

function addLike(postId) {
  var liked = readLikedPosts();
  if (liked.indexOf(postId) >= 0) return;
  liked.push(postId);
  writeLikedPosts(liked);
  request("/likes", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      postId: postId,
      nickname: "访客",
      createdAt: new Date().toISOString()
    })
  }).then(loadSideData).then(renderFeed).catch(function (error) {
    setApiState("错误：" + error.message);
  });
}

$("feedList").onclick = function (event) {
  var likeButton = event.target.closest(".like-button");
  if (likeButton) {
    addLike(likeButton.getAttribute("data-post-id"));
    return;
  }
  var commentButton = event.target.closest(".comment-focus");
  if (commentButton) {
    var postId = commentButton.getAttribute("data-post-id");
    var input = document.querySelector('.comment-form[data-post-id="' + postId + '"] input[name="content"]');
    if (input) input.focus();
  }
};

$("feedList").onsubmit = function (event) {
  var form = event.target.closest(".comment-form");
  if (!form) return;
  event.preventDefault();
  var postId = form.getAttribute("data-post-id");
  var nickname = form.querySelector('input[name="nickname"]').value.trim() || "访客";
  var content = form.querySelector('input[name="content"]').value.trim();
  if (!content) {
    setApiState("请先填写评论内容");
    return;
  }
  request("/comments", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      postId: postId,
      nickname: nickname,
      content: content,
      createdAt: new Date().toISOString()
    })
  }).then(function () {
    form.querySelector('input[name="content"]').value = "";
    return loadSideData();
  }).then(renderFeed).catch(function (error) {
    setApiState("错误：" + error.message);
  });
};

$("refreshBtn").onclick = function () {
  loadNextPage(true);
};

window.addEventListener("scroll", function () {
  var nearBottom = window.innerHeight + window.scrollY >= document.body.offsetHeight - 260;
  if (nearBottom) loadNextPage(false);
});

loadNextPage(true);
