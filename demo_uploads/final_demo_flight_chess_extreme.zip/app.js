(function () {
  var localRoot = "http://127.0.0.1:8000";
  window.API_ROOT = window.API_ROOT || localRoot;
  window.API_BASE = window.API_BASE || localRoot + "/api/codex_live_001";
})();

var COLORS = ["red", "yellow", "blue", "green"];
var COLOR_NAMES = { red: "红色", yellow: "黄色", blue: "蓝色", green: "绿色" };
var START_INDEX = { red: 0, yellow: 13, blue: 26, green: 39 };
var MAIN_PATH = [
  [5,1],[5,2],[5,3],[5,4],[5,5],[4,5],[3,5],[2,5],[1,5],[0,5],[0,6],[0,8],[0,7],
  [1,9],[2,9],[3,9],[4,9],[5,9],[5,10],[5,11],[5,12],[5,13],[5,14],[6,14],[8,14],[7,14],
  [9,13],[9,12],[9,11],[9,10],[9,9],[10,9],[11,9],[12,9],[13,9],[14,9],[14,8],[14,6],[14,7],
  [13,5],[12,5],[11,5],[10,5],[9,5],[9,4],[9,3],[9,2],[9,1],[9,0],[8,0],[6,0],[7,0]
];
var HOME_LANES = {
  red: [[7,1],[7,2],[7,3],[7,4],[7,5],[7,6]],
  yellow: [[1,7],[2,7],[3,7],[4,7],[5,7],[6,7]],
  blue: [[7,13],[7,12],[7,11],[7,10],[7,9],[7,8]],
  green: [[13,7],[12,7],[11,7],[10,7],[9,7],[8,7]]
};
var BASE_SPOTS = {
  red: [[1,1],[1,3],[3,1],[3,3]],
  yellow: [[1,11],[1,13],[3,11],[3,13]],
  blue: [[11,11],[11,13],[13,11],[13,13]],
  green: [[11,1],[11,3],[13,1],[13,3]]
};
var BASE_AREAS = {
  red: { r1: 0, r2: 4, c1: 0, c2: 4 },
  yellow: { r1: 0, r2: 4, c1: 10, c2: 14 },
  blue: { r1: 10, r2: 14, c1: 10, c2: 14 },
  green: { r1: 10, r2: 14, c1: 0, c2: 4 }
};
var APRON_SPOTS = {
  red: [5, 0],
  yellow: [0, 9],
  blue: [9, 14],
  green: [14, 5]
};
var FLIGHT_JUMPS = {
  red: { from: 6, to: 15 },
  yellow: { from: 19, to: 28 },
  blue: { from: 32, to: 41 },
  green: { from: 45, to: 2 }
};
var MAIN_PROGRESS_START = 1;
var MAIN_PROGRESS_END = MAIN_PATH.length;
var HOME_PROGRESS_START = MAIN_PROGRESS_END + 1;
var FINISH_PROGRESS = MAIN_PROGRESS_END + HOME_LANES.red.length;
var pollTimer = 0;
var currentRoomRecord = null;
var currentRoom = null;
var currentPlayer = null;
var localOnlyRoom = false;
var animatingMove = null;
var diceGuideHidden = false;

function $(id) {
  return document.getElementById(id);
}

function setStatus(text) {
  $("connectionStatus").textContent = text;
}

function request(path, options) {
  return fetch(API_BASE + path, options || {})
    .then(function (res) {
      return res.json().then(function (body) {
        if (!res.ok || body.success === false) {
          throw new Error(body.message || body.detail || "请求失败");
        }
        return body.data;
      });
    });
}

function roomCode() {
  return $("roomCodeInput").value.trim() || "demo-room-01";
}

function nowText() {
  return new Date().toLocaleTimeString("zh-CN", { hour: "2-digit", minute: "2-digit", second: "2-digit" });
}

function sessionKey(code) {
  return "flight-room-player-" + code;
}

function readStoredPlayer(code) {
  try {
    return JSON.parse(localStorage.getItem(sessionKey(code)) || "null");
  } catch (error) {
    return null;
  }
}

function writeStoredPlayer(player) {
  if (!player || !player.roomCode) return;
  localStorage.setItem(sessionKey(player.roomCode), JSON.stringify(player));
}

function removeStoredPlayer(code) {
  localStorage.removeItem(sessionKey(code));
}

function passwordFromInput() {
  return $("roomPasswordInput").value.trim();
}

function bufferToHex(buffer) {
  return Array.from(new Uint8Array(buffer)).map(function (byte) {
    return byte.toString(16).padStart(2, "0");
  }).join("");
}

function hashPassword(password, code) {
  if (!password) return Promise.resolve("");
  var text = "flight-room:" + code + ":" + password;
  if (window.crypto && window.crypto.subtle && window.TextEncoder) {
    return window.crypto.subtle.digest("SHA-256", new TextEncoder().encode(text)).then(function (buffer) {
      return "sha256:" + bufferToHex(buffer);
    });
  }
  return Promise.resolve("fallback:" + text);
}

function hasBrokenText(text) {
  if (typeof text !== "string") return false;
  return text.indexOf("??") >= 0 || text.indexOf("é") >= 0 || text.indexOf("æ") >= 0;
}

function cleanRoomTitle(data, code, fallback) {
  var title = data && typeof data.title === "string" ? data.title : "";
  if (!title || hasBrokenText(title)) return fallback;
  return title;
}

function cleanRoomLog(log, fallback) {
  if (!Array.isArray(log)) return fallback;
  var cleaned = log.filter(function (item) {
    return typeof item === "string" && item.trim() && !hasBrokenText(item);
  });
  return cleaned.length ? cleaned.slice(-18) : fallback;
}

function pieceCountFromInput() {
  return Math.max(1, Math.min(4, Number($("pieceCountInput").value || 4)));
}

function createPieces(pieceCount) {
  var pieces = {};
  COLORS.forEach(function (color) {
    pieces[color] = Array(pieceCount).fill(-1);
  });
  return pieces;
}

function createSinglePlayers() {
  var players = {};
  COLORS.forEach(function (color) {
    players[color] = { name: COLOR_NAMES[color] + "玩家", color: color, joinedAt: new Date().toISOString() };
  });
  return players;
}

function createInitialRoom(code, mode, settings) {
  var pieceCount = Math.max(1, Math.min(4, Number(settings.pieceCount || 4)));
  return {
    version: 3,
    roomCode: code,
    title: "飞行棋房间 " + code,
    mode: mode || "online",
    passwordHash: settings.passwordHash || "",
    settings: {
      pieceCount: pieceCount,
      canCapture: Boolean(settings.canCapture),
      canFly: true,
      canFlightLaneCapture: settings.canFlightLaneCapture !== false
    },
    turnColor: "red",
    turnOrder: COLORS.slice(),
    orderState: {
      decided: false,
      method: mode === "single" ? "manual" : "dice",
      rolls: {},
      notes: []
    },
    round: 1,
    lastDice: null,
    pendingRoll: null,
    players: mode === "single" ? createSinglePlayers() : {},
    pieces: createPieces(pieceCount),
    log: ["房间已创建。规则：6 点才能出基地，先到停机坪；超过终点会折返。"],
    updatedAt: new Date().toISOString()
  };
}

function fitPieceArray(list, pieceCount) {
  var next = Array.isArray(list) ? list.slice(0, pieceCount) : [];
  while (next.length < pieceCount) next.push(-1);
  return next.map(function (value) {
    var numeric = Number(value);
    if (!Number.isFinite(numeric)) return -1;
    return numeric < -2 ? -1 : numeric;
  });
}

function normalizePendingRoll(data, turnColor) {
  if (!data || !data.pendingRoll) return null;
  var value = Number(data.pendingRoll.value);
  var color = data.pendingRoll.color;
  if (COLORS.indexOf(color) < 0 || color !== turnColor || value < 1 || value > 6) return null;
  return {
    color: color,
    value: value,
    player: data.pendingRoll.player || "",
    at: data.pendingRoll.at || data.updatedAt || new Date().toISOString()
  };
}

function normalizeTurnOrder(data, mode, players) {
  var active = mode === "single" ? COLORS.slice() : COLORS.filter(function (color) {
    return players && players[color];
  });
  if (!active.length) active = mode === "single" ? COLORS.slice() : [];
  var order = Array.isArray(data && data.turnOrder) ? data.turnOrder.filter(function (color) {
    return COLORS.indexOf(color) >= 0 && active.indexOf(color) >= 0;
  }) : [];
  active.forEach(function (color) {
    if (order.indexOf(color) < 0) order.push(color);
  });
  return order.length ? order : COLORS.slice();
}

function normalizeOrderState(data, fallbackMode, hasSavedOrder) {
  var state = data && data.orderState ? data.orderState : null;
  if (state && typeof state === "object") {
    return {
      decided: Boolean(state.decided),
      method: state.method === "manual" ? "manual" : "dice",
      rolls: state.rolls && typeof state.rolls === "object" ? state.rolls : {},
      notes: Array.isArray(state.notes) ? state.notes.slice(-6) : []
    };
  }
  return {
    decided: Boolean(hasSavedOrder),
    method: fallbackMode === "single" ? "manual" : "dice",
    rolls: {},
    notes: hasSavedOrder ? ["旧房间沿用已有回合顺序。"] : []
  };
}

function normalizeRoom(data, code) {
  var settings = data && data.settings ? data.settings : {};
  var pieceCount = Math.max(1, Math.min(4, Number(settings.pieceCount || (data && data.pieceCount) || 4)));
  var mode = data && data.mode === "single" ? "single" : "online";
  var roomCodeValue = data && data.roomCode ? data.roomCode : code;
  var base = createInitialRoom(roomCodeValue, mode, {
      pieceCount: pieceCount,
      canCapture: settings.canCapture !== false,
      canFly: settings.canFly !== false
  });
  var pieces = {};
  COLORS.forEach(function (color) {
    pieces[color] = fitPieceArray(data && data.pieces ? data.pieces[color] : null, pieceCount);
  });
  var turnColor = data && COLORS.indexOf(data.turnColor) >= 0 ? data.turnColor : "red";
  var turnOrder = normalizeTurnOrder(data, mode, data && data.players ? data.players : base.players);
  var hasSavedOrder = Boolean(data && (data.orderState || data.turnOrder));
  return {
    version: 3,
    roomCode: roomCodeValue,
    title: cleanRoomTitle(data, roomCodeValue, base.title),
    mode: mode,
    passwordHash: data && typeof data.passwordHash === "string" ? data.passwordHash : "",
    settings: {
      pieceCount: pieceCount,
      canCapture: data && data.settings ? data.settings.canCapture !== false : true,
      canFly: true,
      canFlightLaneCapture: data && data.settings ? data.settings.canFlightLaneCapture !== false : true
    },
    turnColor: turnOrder.indexOf(turnColor) >= 0 ? turnColor : turnOrder[0],
    turnOrder: turnOrder,
    orderState: normalizeOrderState(data, mode, hasSavedOrder),
    round: Number((data && data.round) || 1),
    lastDice: data && data.lastDice ? data.lastDice : null,
    pendingRoll: normalizePendingRoll(data, turnColor),
    players: data && data.players ? data.players : base.players,
    pieces: pieces,
    log: cleanRoomLog(data && data.log, base.log),
    updatedAt: data && data.updatedAt ? data.updatedAt : base.updatedAt
  };
}

function isMainProgress(progress) {
  return progress >= MAIN_PROGRESS_START && progress <= MAIN_PROGRESS_END;
}

function absoluteMainIndex(color, progress) {
  return (START_INDEX[color] + progress - MAIN_PROGRESS_START) % MAIN_PATH.length;
}

function progressFromMainIndex(color, mainIndex) {
  return ((mainIndex - START_INDEX[color] + MAIN_PATH.length) % MAIN_PATH.length) + MAIN_PROGRESS_START;
}

function coordKey(coord) {
  return coord[0] + "," + coord[1];
}

function coordForPiece(color, pieceIndex, progress) {
  if (progress < 0) return BASE_SPOTS[color][pieceIndex] || BASE_SPOTS[color][0];
  if (progress === 0) return APRON_SPOTS[color];
  if (isMainProgress(progress)) return MAIN_PATH[absoluteMainIndex(color, progress)];
  var laneIndex = Math.min(HOME_LANES[color].length - 1, progress - HOME_PROGRESS_START);
  return HOME_LANES[color][laneIndex];
}

function inArea(row, col, area) {
  return row >= area.r1 && row <= area.r2 && col >= area.c1 && col <= area.c2;
}

function cellBaseColor(row, col) {
  for (var color in BASE_AREAS) {
    if (inArea(row, col, BASE_AREAS[color])) return color;
  }
  return "";
}

function pathIndexAt(row, col) {
  for (var i = 0; i < MAIN_PATH.length; i += 1) {
    if (MAIN_PATH[i][0] === row && MAIN_PATH[i][1] === col) return i;
  }
  return -1;
}

function laneColorAt(row, col) {
  for (var color in HOME_LANES) {
    if (HOME_LANES[color].some(function (coord) { return coord[0] === row && coord[1] === col; })) return color;
  }
  return "";
}

function finalWedgeColorAt(row, col) {
  for (var color in HOME_LANES) {
    var coord = HOME_LANES[color][HOME_LANES[color].length - 1];
    if (coord[0] === row && coord[1] === col) return color;
  }
  return "";
}

function startColorAt(row, col) {
  for (var color in START_INDEX) {
    var coord = MAIN_PATH[START_INDEX[color]];
    if (coord[0] === row && coord[1] === col) return color;
  }
  return "";
}

function apronColorAt(row, col) {
  for (var color in APRON_SPOTS) {
    var coord = APRON_SPOTS[color];
    if (coord[0] === row && coord[1] === col) return color;
  }
  return "";
}

function flightMarkAt(row, col) {
  for (var color in FLIGHT_JUMPS) {
    var jump = FLIGHT_JUMPS[color];
    var fromCoord = MAIN_PATH[jump.from];
    var toCoord = MAIN_PATH[jump.to];
    if (fromCoord[0] === row && fromCoord[1] === col) return { color: color, type: "from" };
    if (toCoord[0] === row && toCoord[1] === col) return { color: color, type: "to" };
  }
  return null;
}

function piecesByCell() {
  var map = {};
  if (!currentRoom) return map;
  COLORS.forEach(function (color) {
    (currentRoom.pieces[color] || []).forEach(function (progress, index) {
      var coord = coordForPiece(color, index, progress);
      var key = coordKey(coord);
      if (!map[key]) map[key] = [];
      map[key].push({ color: color, index: index, progress: progress, completed: progress === -2 });
    });
  });
  return map;
}

function renderBoard() {
  var board = $("board");
  var pieceMap = piecesByCell();
  var html = [];
  for (var row = 0; row < 15; row += 1) {
    for (var col = 0; col < 15; col += 1) {
      var classes = ["board-cell"];
      var baseColor = cellBaseColor(row, col);
      var pathIndex = pathIndexAt(row, col);
      var laneColor = laneColorAt(row, col);
      var finalWedgeColor = finalWedgeColorAt(row, col);
      var startColor = startColorAt(row, col);
      var apronColor = apronColorAt(row, col);
      var flightMark = flightMarkAt(row, col);
      var key = row + "," + col;
      var label = "";
      if (baseColor) classes.push(baseColor + "-zone corner-home");
      if (pathIndex >= 0) {
        classes.push("path");
        label = "·";
      }
      if (laneColor) classes.push(laneColor + "-lane");
      if (finalWedgeColor) classes.push("final-wedge", finalWedgeColor + "-wedge");
      if (startColor) {
        classes.push(startColor + "-start");
        label = "起";
      }
      if (apronColor) {
        classes.push("apron-cell", apronColor + "-apron");
        label = "0";
      }
      if (flightMark) {
        classes.push("flight-mark", flightMark.color + "-flight", "flight-" + flightMark.type);
        label = flightMark.type === "from" ? "↗" : "★";
      }
      if (row === 7 && col === 7) {
        classes.push("center");
        label = "终";
      }
      COLORS.forEach(function (color) {
        (BASE_SPOTS[color] || []).forEach(function (coord) {
          if (coord[0] === row && coord[1] === col) {
            classes.push("base-slot");
            if ((pieceMap[key] || []).some(function (piece) { return piece.color === color && piece.completed; })) {
              classes.push(color + "-completed-slot");
            }
            label = "";
          }
        });
      });
      var pieces = (pieceMap[key] || []).map(function (piece) {
        var selected = animatingMove && animatingMove.color === piece.color && animatingMove.index === piece.index;
        var movingClass = selected ? " selected moving" + (animatingMove.flight ? " flying" : "") + (animatingMove.hidden ? " hidden" : "") : "";
        return '<span class="plane-piece ' + piece.color + (piece.completed ? " completed" : "") + movingClass + '"><small>' + (piece.index + 1) + '</small></span>';
      }).join("");
      html.push('<div class="' + classes.join(" ") + '">' +
        '<span class="cell-label">' + label + '</span>' +
        '<div class="piece-stack">' + pieces + '</div>' +
      '</div>');
    }
  }
  board.innerHTML = html.join("");
}

function activeColors() {
  if (!currentRoom) return COLORS;
  if (Array.isArray(currentRoom.turnOrder) && currentRoom.turnOrder.length) {
    return currentRoom.turnOrder.filter(function (color) {
      return currentRoom.mode === "single" || Boolean(currentRoom.players[color]);
    });
  }
  if (currentRoom.mode === "single") return COLORS;
  var joined = COLORS.filter(function (color) {
    return Boolean(currentRoom.players[color]);
  });
  return joined.length ? joined : COLORS;
}

function nextTurnColor(color) {
  var active = activeColors();
  var index = active.indexOf(color);
  return active[(index + 1 + active.length) % active.length];
}

function isMyTurnColor(color) {
  if (!currentRoom) return false;
  if (currentRoom.mode === "single") return color === currentRoom.turnColor;
  return currentPlayer && currentPlayer.color === color && currentRoom.turnColor === color;
}

function currentActorColor() {
  if (!currentRoom) return "";
  return currentRoom.mode === "single" ? currentRoom.turnColor : (currentPlayer ? currentPlayer.color : "");
}

function isLocalOnlyRoom() {
  return Boolean(localOnlyRoom && currentRoom && currentRoom.mode === "single");
}

function actorNameFor(color) {
  if (!currentRoom || !color) return "未知玩家";
  if (currentRoom.mode === "single") return COLOR_NAMES[color] + "玩家";
  if (currentPlayer && currentPlayer.color === color) return currentPlayer.name;
  var player = currentRoom.players[color];
  return player ? player.name : COLOR_NAMES[color] + "玩家";
}

function hasPendingRollFor(color) {
  return Boolean(currentRoom && currentRoom.pendingRoll && currentRoom.pendingRoll.color === color && currentRoom.turnColor === color);
}

function canSelectPiece(color) {
  return Boolean(!animatingMove && isOrderDecided() && color && isMyTurnColor(color) && hasPendingRollFor(color));
}

function isOrderDecided() {
  return Boolean(currentRoom && currentRoom.orderState && currentRoom.orderState.decided);
}

function canMovePiece(color, progress) {
  if (!canSelectPiece(color)) return false;
  var dice = Number(currentRoom.pendingRoll.value);
  if (progress === -2) return false;
  if (progress < 0) return dice === 6;
  if (progress === FINISH_PROGRESS) return false;
  return true;
}

function movablePieceIndexes(color) {
  if (!currentRoom || !currentRoom.pieces[color]) return [];
  return currentRoom.pieces[color].map(function (progress, index) {
    return canMovePiece(color, progress) ? index : -1;
  }).filter(function (index) {
    return index >= 0;
  });
}

function progressAfterDice(from, dice) {
  if (from === -2) return from;
  if (from < 0) return dice === 6 ? 0 : from;
  if (from === FINISH_PROGRESS) return from;
  var raw = from + dice;
  if (raw <= FINISH_PROGRESS) return raw;
  var overshoot = raw - FINISH_PROGRESS;
  return FINISH_PROGRESS - overshoot;
}

function maybeApplyFlightJump(color, progress) {
  if (!isMainProgress(progress)) return { progress: progress, jumped: false };
  var mainIndex = absoluteMainIndex(color, progress);
  var jump = FLIGHT_JUMPS[color];
  if (!jump || mainIndex !== jump.from) return { progress: progress, jumped: false };
  return {
    progress: progressFromMainIndex(color, jump.to),
    jumped: true,
    fromIndex: jump.from,
    toIndex: jump.to
  };
}

function buildDiceSteps(from, dice, to) {
  if (from < 0 || to < 0) return [to];
  var steps = [];
  var raw = from + dice;
  if (raw <= FINISH_PROGRESS) {
    for (var forward = from + 1; forward <= to; forward += 1) steps.push(forward);
    return steps.length ? steps : [to];
  }
  for (var up = from + 1; up <= FINISH_PROGRESS; up += 1) steps.push(up);
  for (var back = FINISH_PROGRESS - 1; back >= to; back -= 1) steps.push(back);
  return steps.length ? steps : [to];
}

function animateMove(color, pieceIndex, steps, done, options) {
  if (!steps.length) {
    done();
    return;
  }
  var delay = options && options.delay ? options.delay : 105;
  var settleDelay = options && options.settleDelay ? options.settleDelay : 120;
  var original = currentRoom.pieces[color][pieceIndex];
  var position = 0;
  animatingMove = { color: color, index: pieceIndex, flight: Boolean(options && options.flight) };
  function tick() {
    currentRoom.pieces[color][pieceIndex] = steps[position];
    renderBoard();
    position += 1;
    if (position < steps.length) {
      window.setTimeout(tick, delay);
      return;
    }
    currentRoom.pieces[color][pieceIndex] = original;
    window.setTimeout(function () {
      animatingMove = null;
      done();
    }, settleDelay);
  }
  tick();
}

function animateFlightJump(color, pieceIndex, fromProgress, toProgress, done) {
  var board = $("board");
  if (!board) {
    done();
    return;
  }
  currentRoom.pieces[color][pieceIndex] = fromProgress;
  animatingMove = { color: color, index: pieceIndex, flight: true, hidden: true };
  renderBoard();
  window.requestAnimationFrame(function () {
    var fromCoord = coordForPiece(color, pieceIndex, fromProgress);
    var toCoord = coordForPiece(color, pieceIndex, toProgress);
    var fromCell = board.children[fromCoord[0] * 15 + fromCoord[1]];
    var toCell = board.children[toCoord[0] * 15 + toCoord[1]];
    if (!fromCell || !toCell) {
      currentRoom.pieces[color][pieceIndex] = toProgress;
      animatingMove = null;
      renderBoard();
      done();
      return;
    }
    var boardRect = board.getBoundingClientRect();
    var fromRect = fromCell.getBoundingClientRect();
    var toRect = toCell.getBoundingClientRect();
    var size = Math.max(18, Math.min(fromRect.width, fromRect.height) * 0.58);
    var fromLeft = fromRect.left - boardRect.left + fromRect.width / 2 - size / 2;
    var fromTop = fromRect.top - boardRect.top + fromRect.height / 2 - size / 2;
    var toLeft = toRect.left - boardRect.left + toRect.width / 2 - size / 2;
    var toTop = toRect.top - boardRect.top + toRect.height / 2 - size / 2;
    var ghost = document.createElement("span");
    ghost.className = "plane-piece flight-ghost " + color;
    ghost.innerHTML = "<small>" + (pieceIndex + 1) + "</small>";
    ghost.style.left = fromLeft + "px";
    ghost.style.top = fromTop + "px";
    ghost.style.width = size + "px";
    ghost.style.height = size + "px";
    ghost.style.setProperty("--dx", (toLeft - fromLeft) + "px");
    ghost.style.setProperty("--dy", (toTop - fromTop) + "px");
    ghost.style.setProperty("--mx", ((toLeft - fromLeft) / 2) + "px");
    ghost.style.setProperty("--my", ((toTop - fromTop) / 2 - 18) + "px");
    board.appendChild(ghost);
    window.setTimeout(function () {
      ghost.classList.add("is-flying");
    }, 0);
    window.setTimeout(function () {
      if (ghost.parentNode) ghost.parentNode.removeChild(ghost);
      currentRoom.pieces[color][pieceIndex] = toProgress;
      animatingMove = null;
      renderBoard();
      done();
    }, 520);
  });
}

function pieceText(progress) {
  if (progress === -2) return "已到达";
  if (progress < 0) return "基地";
  if (progress === 0) return "停机坪";
  if (progress === FINISH_PROGRESS) return "终点";
  if (progress >= HOME_PROGRESS_START) return "终点跑道" + (progress - HOME_PROGRESS_START + 1);
  return "主跑道" + progress;
}

function renderPieceControls() {
  if (!currentRoom) {
    $("pieceControls").innerHTML = "";
    return;
  }
  var color = currentActorColor();
  if (!color) {
    $("pieceControls").innerHTML = '<button disabled>请先加入联机房间</button>';
    return;
  }
  $("pieceControls").innerHTML = currentRoom.pieces[color].map(function (progress, index) {
    var enabled = canMovePiece(color, progress);
    return '<button class="piece-button ' + color + '" data-piece-index="' + index + '" ' + (enabled ? "" : "disabled") + '>' +
      COLOR_NAMES[color] + (index + 1) + "号：" + pieceText(progress) +
    '</button>';
  }).join("");
}

function renderOrderPanel() {
  var panel = $("orderPanel");
  if (!panel || !currentRoom) return;
  var active = currentRoom.mode === "single" ? COLORS.slice() : COLORS.filter(function (color) {
    return currentRoom.players[color];
  });
  if (isOrderDecided()) {
    panel.innerHTML = '<div class="order-summary"><b>开局顺序</b><span>' +
      currentRoom.turnOrder.map(function (color, index) {
        return (index + 1) + ". " + COLOR_NAMES[color];
      }).join("　") +
    '</span></div>';
    return;
  }
  var rolls = currentRoom.orderState && currentRoom.orderState.rolls ? currentRoom.orderState.rolls : {};
  var noteHtml = (currentRoom.orderState && currentRoom.orderState.notes || []).map(function (note) {
    return '<p class="muted">' + escapeHtml(note) + '</p>';
  }).join("");
  var rows = (currentRoom.mode === "single" ? COLORS : active).map(function (color, index) {
    var select = currentRoom.mode === "single"
      ? '<select data-order-rank="' + index + '">' + COLORS.map(function (optionColor) {
          return '<option value="' + optionColor + '"' + (optionColor === color ? " selected" : "") + '>' + COLOR_NAMES[optionColor] + '</option>';
        }).join("") + '</select>'
      : '<span class="muted">等待掷骰</span>';
    return '<tr><td><span class="player-dot ' + color + '"></span>' + COLOR_NAMES[color] + '</td><td>' +
      (rolls[color] ? rolls[color] + " 点" : "未掷") + '</td><td>' + select + '</td></tr>';
  }).join("");
  panel.innerHTML =
    '<div class="order-card">' +
      '<div class="order-head"><b>开局顺序</b><span class="muted">' +
        (currentRoom.mode === "single" ? "可掷骰比大小，也可石头剪刀布后按表确认。" : "联机模式用掷骰比大小决定先后。") +
      '</span></div>' +
      '<table class="order-table"><thead><tr><th>颜色</th><th>骰子</th><th>顺序</th></tr></thead><tbody>' + rows + '</tbody></table>' +
      noteHtml +
      '<div class="button-row">' +
        '<button type="button" data-order-action="dice">掷骰比大小</button>' +
        (currentRoom.mode === "single" ? '<button type="button" class="secondary" data-order-action="manual">按表确认顺序</button>' : '') +
      '</div>' +
    '</div>';
}

function rollOrderGroup(colors, notes, rolls) {
  if (colors.length <= 1) return colors.slice();
  var grouped = {};
  colors.forEach(function (color) {
    var value = Math.floor(Math.random() * 6) + 1;
    rolls[color] = value;
    if (!grouped[value]) grouped[value] = [];
    grouped[value].push(color);
  });
  var values = Object.keys(grouped).map(Number).sort(function (a, b) { return b - a; });
  var result = [];
  values.forEach(function (value) {
    var group = grouped[value];
    if (group.length === 1) {
      result.push(group[0]);
      return;
    }
    notes.push(group.map(function (color) { return COLOR_NAMES[color]; }).join("、") + " 同为 " + value + " 点，重新比较。");
    result = result.concat(rollOrderGroup(group, notes, rolls));
  });
  return result;
}

function decideOrderByDice() {
  if (!currentRoom) return;
  var colors = currentRoom.mode === "single" ? COLORS.slice() : COLORS.filter(function (color) {
    return currentRoom.players[color];
  });
  if (!colors.length) return alert("联机房间至少需要一个玩家加入后再决定顺序。");
  var rolls = {};
  var notes = [];
  var order = rollOrderGroup(colors, notes, rolls);
  currentRoom.turnOrder = order;
  currentRoom.turnColor = order[0];
  currentRoom.round = 1;
  currentRoom.orderState = {
    decided: true,
    method: "dice",
    rolls: rolls,
    notes: notes.length ? notes : ["掷骰比大小完成。"]
  };
  currentRoom.log.push(nowText() + " 开局顺序已由掷骰决定：" + order.map(function (color) { return COLOR_NAMES[color]; }).join(" → "));
  saveRoom("开局顺序已确定").catch(function (error) {
    alert(error.message);
  });
}

function decideOrderManually() {
  if (!currentRoom || currentRoom.mode !== "single") return;
  var selects = Array.from(document.querySelectorAll("[data-order-rank]"));
  var order = selects.map(function (select) { return select.value; });
  var unique = order.filter(function (color, index) { return order.indexOf(color) === index; });
  if (unique.length !== COLORS.length) return alert("四个顺序必须分别选择不同颜色。");
  currentRoom.turnOrder = order;
  currentRoom.turnColor = order[0];
  currentRoom.round = 1;
  currentRoom.orderState = {
    decided: true,
    method: "manual",
    rolls: {},
    notes: ["面对面决定顺序后，已按表确认。"]
  };
  currentRoom.log.push(nowText() + " 开局顺序已手动确认：" + order.map(function (color) { return COLOR_NAMES[color]; }).join(" → "));
  saveRoom("开局顺序已确定").catch(function (error) {
    alert(error.message);
  });
}

function renderPlayers() {
  if (!currentRoom) return;
  $("playersList").innerHTML = COLORS.map(function (color) {
    var player = currentRoom.players[color];
    var isMe = currentPlayer && currentPlayer.color === color && currentRoom.mode === "online";
    return '<div class="player-card ' + (isMe ? "is-me " : "") + (currentRoom.turnColor === color ? "is-turn" : "") + '">' +
      '<span class="player-dot ' + color + '"></span>' +
      '<span><b>' + COLOR_NAMES[color] + "</b><br>" + (player ? player.name : "空位") + (isMe ? "（我）" : "") + '</span>' +
      '<span>' + (currentRoom.turnColor === color ? "当前" : "") + '</span>' +
    '</div>';
  }).join("");
}

function renderRules() {
  if (!currentRoom) {
    $("rulesBox").innerHTML = "";
    return;
  }
  $("rulesBox").innerHTML =
    '<div class="rule-item">模式：' + (currentRoom.mode === "single" ? "单机轮换" : "联机对战") + '</div>' +
    '<div class="rule-item">棋子数：每色 ' + currentRoom.settings.pieceCount + ' 枚</div>' +
    '<div class="rule-item">出基地：必须掷出 6 点，先到第 0 格停机坪</div>' +
    '<div class="rule-item">奖励：掷出 6 点并移动后可再掷一次</div>' +
    '<div class="rule-item">飞跃：默认开启，箭头格直线飞到星标格</div>' +
    '<div class="rule-item">飞跃撞回：' + (currentRoom.settings.canFlightLaneCapture ? "开启，飞跃穿过终点跑道时会撞回异色棋子" : "关闭") + '</div>' +
    '<div class="rule-item">吃子：' + (currentRoom.settings.canCapture ? "开启，同格异色棋子回基地" : "关闭，异色同格只碰撞") + '</div>' +
    '<div class="rule-item">终点：超过中心终点会按多出的步数折返</div>' +
    '<div class="rule-item">单机：只保存在本浏览器，不写入后端</div>';
}

function renderLog() {
  $("moveLog").innerHTML = currentRoom.log.slice().reverse().map(function (item) {
    return "<li>" + item + "</li>";
  }).join("");
}

function setDice(value, rolling) {
  var dice = $("diceCube");
  if (rolling) dice.classList.add("rolling");
  window.setTimeout(function () {
    dice.className = "dice-cube face-" + (value || 1);
    $("diceValue").textContent = value || "?";
  }, rolling ? 220 : 0);
  if (rolling) {
    window.setTimeout(function () {
      dice.classList.remove("rolling");
    }, 620);
  }
}

function flashScreen(color, className, duration) {
  document.body.setAttribute("data-flash-color", color || "red");
  document.body.classList.remove("six-screen", "capture-screen", "win-screen");
  window.setTimeout(function () {
    document.body.classList.add(className);
  }, 0);
  window.setTimeout(function () {
    document.body.classList.remove(className);
  }, duration || 1300);
}

function showSixBonus(color) {
  var panel = document.querySelector(".board-panel");
  if (!panel) return;
  panel.classList.remove("six-bonus", "capture-bonus", "collision-bonus", "win-bonus");
  panel.setAttribute("data-flash-color", color || (currentRoom ? currentRoom.turnColor : "red"));
  flashScreen(color || (currentRoom ? currentRoom.turnColor : "red"), "six-screen", 1300);
  window.setTimeout(function () {
    panel.classList.add("six-bonus");
  }, 0);
  window.setTimeout(function () {
    panel.classList.remove("six-bonus");
  }, 1300);
}

function showCaptureBonus(color) {
  var panel = document.querySelector(".board-panel");
  if (!panel) return;
  panel.classList.remove("six-bonus", "capture-bonus", "collision-bonus", "win-bonus");
  panel.setAttribute("data-flash-color", color);
  flashScreen(color, "capture-screen", 1300);
  window.setTimeout(function () {
    panel.classList.add("capture-bonus");
  }, 0);
  window.setTimeout(function () {
    panel.classList.remove("capture-bonus");
  }, 1300);
}

function showCollisionBonus(color) {
  var panel = document.querySelector(".board-panel");
  if (!panel) return;
  panel.classList.remove("six-bonus", "capture-bonus", "collision-bonus", "win-bonus");
  panel.setAttribute("data-flash-color", color);
  flashScreen(color, "capture-screen", 1050);
  window.setTimeout(function () {
    panel.classList.add("collision-bonus");
  }, 0);
  window.setTimeout(function () {
    panel.classList.remove("collision-bonus");
  }, 1050);
}

function showWinBonus(color) {
  var panel = document.querySelector(".board-panel");
  if (!panel) return;
  panel.classList.remove("six-bonus", "capture-bonus", "collision-bonus", "win-bonus");
  panel.setAttribute("data-flash-color", color);
  flashScreen(color, "win-screen", 1500);
  window.setTimeout(function () {
    panel.classList.add("win-bonus");
  }, 0);
  window.setTimeout(function () {
    panel.classList.remove("win-bonus");
  }, 1500);
}

function renderRollControl() {
  var button = $("rollDiceBtn");
  var state = $("rollState");
  var guide = $("diceGuide");
  if (!currentRoom) {
    button.disabled = true;
    guide.style.display = "none";
    state.textContent = "请先进入房间";
    return;
  }
  setTurnVisual(currentRoom.turnColor);
  if (!isOrderDecided()) {
    button.disabled = true;
    guide.style.display = "none";
    state.textContent = "请先决定开局顺序";
    return;
  }
  guide.style.display = diceGuideHidden ? "none" : "";
  var color = currentActorColor();
  if (!color) {
    button.disabled = true;
    state.textContent = "联机模式请先加入房间";
    return;
  }
  if (!isMyTurnColor(color)) {
    button.disabled = true;
    state.textContent = "当前轮到 " + COLOR_NAMES[currentRoom.turnColor];
    return;
  }
  if (currentRoom.pendingRoll) {
    button.disabled = true;
    if (currentRoom.pendingRoll.color === color) {
      state.textContent = currentRoom.pendingRoll.value === 6
        ? "已掷出 6 点，选择棋子后可再掷一次"
        : "已掷出 " + currentRoom.pendingRoll.value + " 点，请选择棋子";
    } else {
      state.textContent = COLOR_NAMES[currentRoom.pendingRoll.color] + "已掷出 " + currentRoom.pendingRoll.value + " 点，等待走棋";
    }
    return;
  }
  button.disabled = false;
  state.textContent = "先掷骰子，再选择棋子";
}

function setTurnVisual(color) {
  var diceButton = $("rollDiceBtn");
  var panel = document.querySelector(".board-panel");
  COLORS.forEach(function (itemColor) {
    diceButton.classList.remove(itemColor);
    if (panel) panel.classList.remove("turn-" + itemColor);
  });
  if (COLORS.indexOf(color) >= 0) {
    diceButton.classList.add(color);
    if (panel) panel.classList.add("turn-" + color);
  }
}

function renderRoom() {
  if (!currentRoom) return;
  $("roomTitle").textContent = currentRoom.title;
  $("turnText").textContent = "";
  $("roomModeBadge").textContent = currentRoom.mode === "single" ? "单机" : "联机";
  var identity = "当前身份：";
  if (currentRoom.mode === "single") {
    identity += "单机轮换，正在操作 " + COLOR_NAMES[currentRoom.turnColor];
  } else if (currentPlayer) {
    identity += currentPlayer.name + " / " + COLOR_NAMES[currentPlayer.color];
  } else {
    identity += "未加入";
  }
  $("identityText").textContent = "";
  $("roomMeta").textContent = (currentRoom.mode === "single" ? "单机轮换" : (currentPlayer ? currentPlayer.name + " / " + COLOR_NAMES[currentPlayer.color] : "联机")) +
    " · " + (isOrderDecided() ? "当前 " + COLOR_NAMES[currentRoom.turnColor] + " · 第 " + currentRoom.round + " 轮" : "等待开局顺序");
  if (currentRoom.pendingRoll) {
    $("moveHint").textContent = COLOR_NAMES[currentRoom.pendingRoll.color] + "已掷出 " + currentRoom.pendingRoll.value + " 点。骰子已锁定，等待选择棋子。";
  } else if (!isOrderDecided()) {
    $("moveHint").textContent = "先在上方决定开局顺序，再开始掷骰走棋。";
  } else {
    $("moveHint").textContent = currentRoom.mode === "single"
      ? "单机模式按当前颜色轮换。轮到当前颜色时先掷骰子。"
      : "联机模式只能操作自己加入时选择的颜色。轮到你时先掷骰子。";
  }
  setDice(currentRoom.pendingRoll ? currentRoom.pendingRoll.value : (currentRoom.lastDice || 1), false);
  renderBoard();
  renderOrderPanel();
  renderRollControl();
  renderPieceControls();
  renderPlayers();
  renderRules();
  renderLog();
  syncFormToRoom();
}

function syncFormToRoom() {
  if (!currentRoom) return;
  $("roomModeInput").value = currentRoom.mode;
  $("pieceCountInput").value = String(currentRoom.settings.pieceCount);
  $("captureInput").checked = currentRoom.settings.canCapture;
  $("flightLaneCaptureInput").checked = currentRoom.settings.canFlightLaneCapture !== false;
  var locked = Boolean(currentRoomRecord) || isLocalOnlyRoom();
  $("roomModeInput").disabled = locked;
  $("pieceCountInput").disabled = locked;
  $("captureInput").disabled = locked;
  $("flightLaneCaptureInput").disabled = locked;
  $("leaveRoomBtn").disabled = !locked;
  $("onlineJoinFields").style.display = currentRoom.mode === "single" ? "none" : "block";
}

function escapeHtml(text) {
  return String(text).replace(/[&<>"']/g, function (char) {
    return ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[char];
  });
}

function fetchRoomRecords() {
  return request("/rooms?page=1&pageSize=50")
    .then(function (page) {
      return (page.items || []).filter(function (item) {
        return item.data && item.data.roomCode;
      });
    });
}

function findRoomRecord(records, code) {
  return records.find(function (item) {
    return item.data && item.data.roomCode === code;
  });
}

function roomPlayerCount(room) {
  return COLORS.filter(function (color) {
    return room.players && room.players[color];
  }).length;
}

function renderRoomsList(records) {
  var box = $("roomsList");
  if (!records.length) {
    box.textContent = "暂无房间。";
    return;
  }
  box.innerHTML = records.map(function (item) {
    var room = normalizeRoom(item.data, item.data.roomCode);
    var passwordTag = room.passwordHash ? '<span class="room-tag locked">需密码</span>' : '<span class="room-tag">无密码</span>';
    return '<div class="room-item">' +
      '<div><b>' + escapeHtml(room.roomCode) + '</b>' +
      '<div class="room-meta">' +
      '<span class="room-tag">' + (room.mode === "single" ? "单机" : "联机") + '</span>' +
      '<span class="room-tag">' + roomPlayerCount(room) + " 人</span>" +
      passwordTag +
      '</div></div>' +
      '<button class="secondary" type="button" data-room-code="' + escapeHtml(room.roomCode) + '">选择</button>' +
    '</div>';
  }).join("");
}

function refreshRoomList() {
  $("roomsList").textContent = "正在读取房间...";
  return fetchRoomRecords().then(function (records) {
    renderRoomsList(records);
    return records;
  }).catch(function (error) {
    $("roomsList").textContent = "读取失败：" + error.message;
    return [];
  });
}

function verifyRoomPassword(room) {
  if (!room.passwordHash) return Promise.resolve();
  var password = passwordFromInput();
  if (!password) {
    return Promise.reject(new Error("这个房间设置了密码，请先填写房间密码。"));
  }
  return hashPassword(password, room.roomCode).then(function (hash) {
    if (hash !== room.passwordHash) throw new Error("房间密码不正确。");
  });
}

function createRoomRecord(code) {
  var mode = $("roomModeInput").value;
  currentPlayer = null;
  localOnlyRoom = false;
  return hashPassword(passwordFromInput(), code).then(function (passwordHash) {
    var createdRoom = createInitialRoom(code, mode, {
      pieceCount: pieceCountFromInput(),
      canCapture: $("captureInput").checked,
      canFlightLaneCapture: $("flightLaneCaptureInput").checked,
      passwordHash: passwordHash
    });
    return request("/rooms", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(createdRoom)
    }).then(function (created) {
      currentRoomRecord = created;
      currentRoom = normalizeRoom(created.data, code);
      setStatus("已创建房间");
      renderRoom();
      refreshRoomList();
      return currentRoom;
    });
  });
}

function loadRoom(createIfMissing) {
  var code = roomCode();
  localOnlyRoom = false;
  setStatus("同步中...");
  return fetchRoomRecords()
    .then(function (records) {
      renderRoomsList(records);
      var matched = findRoomRecord(records, code);
      if (matched) {
        currentRoomRecord = matched;
        currentRoom = normalizeRoom(matched.data, code);
        var stored = readStoredPlayer(code);
        if (stored && currentRoom.mode === "online" && currentRoom.players[stored.color] && currentRoom.players[stored.color].name === stored.name) {
          currentPlayer = stored;
        } else if (currentRoom.mode === "online") {
          currentPlayer = null;
        }
        setStatus("已同步 " + nowText());
        renderRoom();
        return currentRoom;
      }
      if (!createIfMissing) throw new Error("房间不存在，请先创建或加入");
      return createRoomRecord(code);
    })
    .catch(function (error) {
      setStatus("错误：" + error.message);
      throw error;
    });
}

function saveRoom(message, actorOverride) {
  if (isLocalOnlyRoom()) {
    renderRoom();
    return Promise.resolve(currentRoom);
  }
  if (!currentRoomRecord || !currentRoom) throw new Error("请先创建或加入房间");
  currentRoom.updatedAt = new Date().toISOString();
  return request("/rooms/" + encodeURIComponent(currentRoomRecord.id), {
    method: "PUT",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(currentRoom)
  }).then(function (updated) {
    currentRoomRecord = updated;
    currentRoom = normalizeRoom(updated.data, currentRoom.roomCode);
    if (message) return addMove(message, actorOverride).then(function () { renderRoom(); });
    renderRoom();
  });
}

function addMove(message, actorOverride) {
  var actor = actorOverride || (currentRoom.mode === "single"
    ? { color: currentRoom.turnColor, name: COLOR_NAMES[currentRoom.turnColor] + "玩家" }
    : (currentPlayer || { color: "", name: "未知玩家" }));
  return request("/moves", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      roomCode: currentRoom.roomCode,
      color: actor.color,
      player: actor.name,
      message: message,
      at: new Date().toISOString()
    })
  }).catch(function () {
    return null;
  });
}

function validateOnlineJoin(name, color) {
  var stored = readStoredPlayer(currentRoom.roomCode);
  if (stored && currentRoom.players[stored.color] && currentRoom.players[stored.color].name === stored.name) {
    throw new Error("你已经以 " + stored.name + " / " + COLOR_NAMES[stored.color] + " 加入了这个房间，联机模式下不能换色重复加入。");
  }
  if (currentRoom.players[color]) {
    throw new Error(COLOR_NAMES[color] + "已经有玩家，不能重复加入。");
  }
  var sameName = COLORS.some(function (itemColor) {
    return currentRoom.players[itemColor] && currentRoom.players[itemColor].name === name;
  });
  if (sameName) {
    throw new Error("房间里已经有同名玩家，换一个昵称再加入。");
  }
}

function prepareRoomForJoin() {
  var code = roomCode();
  if ($("roomModeInput").value === "single") {
    currentRoomRecord = null;
    localOnlyRoom = true;
    currentPlayer = { roomCode: code, name: "本机玩家", color: "" };
    currentRoom = createInitialRoom(code, "single", {
      pieceCount: pieceCountFromInput(),
      canCapture: $("captureInput").checked,
      canFlightLaneCapture: $("flightLaneCaptureInput").checked
    });
    currentRoom.log.push(nowText() + " 开始本地单机房间，不写入后端。");
    setStatus("本地单机");
    renderRoom();
    return Promise.resolve(currentRoom);
  }
  setStatus("检查房间...");
  return fetchRoomRecords().then(function (records) {
    renderRoomsList(records);
    var matched = findRoomRecord(records, code);
    if (!matched) return createRoomRecord(code);

    currentRoomRecord = matched;
    currentRoom = normalizeRoom(matched.data, code);
    var stored = readStoredPlayer(code);
    if (stored && currentRoom.mode === "online" && currentRoom.players[stored.color] && currentRoom.players[stored.color].name === stored.name) {
      currentPlayer = stored;
    } else {
      currentPlayer = null;
    }
    renderRoom();
    if (!confirm("房间 " + code + " 已存在，是否加入？")) {
      setStatus("已取消加入");
      return null;
    }
    return verifyRoomPassword(currentRoom).then(function () {
      setStatus("密码已通过");
      return currentRoom;
    });
  });
}

function startPollingRoom() {
  window.clearInterval(pollTimer);
  pollTimer = window.setInterval(function () {
    loadRoom(false).catch(function () {});
  }, 3000);
}

function joinRoom() {
  prepareRoomForJoin().then(function (room) {
    if (!room) return null;
    if (currentRoom.mode === "single") {
      currentPlayer = { roomCode: currentRoom.roomCode, name: "本机玩家", color: "" };
      currentRoom.players = createSinglePlayers();
      currentRoom.log.push(nowText() + " 进入单机房间，同一电脑轮换四个颜色。");
      return saveRoom("进入单机房间 " + currentRoom.roomCode);
    }
    if (currentPlayer && currentRoom.players[currentPlayer.color] && currentRoom.players[currentPlayer.color].name === currentPlayer.name) {
      setStatus("已回到房间");
      renderRoom();
      return currentRoom;
    }
    var name = $("playerNameInput").value.trim() || "玩家";
    var color = $("playerColorInput").value;
    validateOnlineJoin(name, color);
    var firstOnlinePlayer = !COLORS.some(function (itemColor) {
      return Boolean(currentRoom.players[itemColor]);
    });
    currentPlayer = { roomCode: currentRoom.roomCode, name: name, color: color };
    currentRoom.players[color] = {
      name: name,
      color: color,
      joinedAt: new Date().toISOString()
    };
    if (firstOnlinePlayer || !currentRoom.players[currentRoom.turnColor]) {
      currentRoom.turnColor = color;
    }
    writeStoredPlayer(currentPlayer);
    currentRoom.log.push(nowText() + " " + COLOR_NAMES[color] + "玩家 " + name + " 加入房间。");
    return saveRoom(name + " 加入 " + currentRoom.roomCode);
  }).then(function (result) {
    if (result === null) return;
    if (isLocalOnlyRoom()) return;
    startPollingRoom();
  }).catch(function (error) {
    alert(error.message);
  });
}

function captureOpponents(actorColor, landingProgress) {
  if (!currentRoom.settings.canCapture || !isMainProgress(landingProgress)) return [];
  var landingIndex = absoluteMainIndex(actorColor, landingProgress);
  var captured = [];
  COLORS.forEach(function (color) {
    if (color === actorColor) return;
    currentRoom.pieces[color].forEach(function (progress, index) {
      if (isMainProgress(progress) && absoluteMainIndex(color, progress) === landingIndex) {
        currentRoom.pieces[color][index] = -1;
        captured.push(COLOR_NAMES[color] + (index + 1) + "号");
      }
    });
  });
  return captured;
}

function findCollisions(actorColor, actorPieceIndex, landingProgress) {
  if (!isMainProgress(landingProgress)) return [];
  var landingIndex = absoluteMainIndex(actorColor, landingProgress);
  var collisions = [];
  COLORS.forEach(function (color) {
    if (color === actorColor) return;
    currentRoom.pieces[color].forEach(function (progress, index) {
      if (isMainProgress(progress) && absoluteMainIndex(color, progress) === landingIndex) {
        collisions.push(COLOR_NAMES[color] + (index + 1) + "号");
      }
    });
  });
  return collisions;
}

function straightCellsBetween(fromCoord, toCoord) {
  var cells = [];
  if (fromCoord[0] === toCoord[0]) {
    var row = fromCoord[0];
    var c1 = Math.min(fromCoord[1], toCoord[1]) + 1;
    var c2 = Math.max(fromCoord[1], toCoord[1]) - 1;
    for (var col = c1; col <= c2; col += 1) cells.push(row + "," + col);
  } else if (fromCoord[1] === toCoord[1]) {
    var colFixed = fromCoord[1];
    var r1 = Math.min(fromCoord[0], toCoord[0]) + 1;
    var r2 = Math.max(fromCoord[0], toCoord[0]) - 1;
    for (var rowFixed = r1; rowFixed <= r2; rowFixed += 1) cells.push(rowFixed + "," + colFixed);
  }
  return cells;
}

function captureFlightLaneOpponents(actorColor, pieceIndex, fromProgress, toProgress) {
  if (!currentRoom.settings.canFlightLaneCapture) return [];
  var fromCoord = coordForPiece(actorColor, pieceIndex, fromProgress);
  var toCoord = coordForPiece(actorColor, pieceIndex, toProgress);
  var crossed = straightCellsBetween(fromCoord, toCoord);
  if (!crossed.length) return [];
  var captured = [];
  COLORS.forEach(function (color) {
    if (color === actorColor) return;
    currentRoom.pieces[color].forEach(function (progress, index) {
      if (progress < HOME_PROGRESS_START || progress > FINISH_PROGRESS) return;
      var coord = coordForPiece(color, index, progress);
      if (crossed.indexOf(coordKey(coord)) >= 0) {
        currentRoom.pieces[color][index] = -1;
        captured.push(COLOR_NAMES[color] + (index + 1) + "号");
      }
    });
  });
  return captured;
}

function rollDice() {
  if (!currentRoom) return alert("请先创建或加入房间");
  if (!isOrderDecided()) return alert("请先决定开局顺序。");
  var actorColor = currentActorColor();
  if (!actorColor) return alert("请先加入联机房间");
  if (!isMyTurnColor(actorColor)) {
    return alert("现在是 " + COLOR_NAMES[currentRoom.turnColor] + " 的回合");
  }
  if (currentRoom.pendingRoll) {
    return alert("本回合已经掷出 " + currentRoom.pendingRoll.value + " 点，请先选择棋子。");
  }
  diceGuideHidden = true;
  $("diceGuide").style.display = "none";
  var dice = Math.floor(Math.random() * 6) + 1;
  var playerName = actorNameFor(actorColor);
  setDice(dice, true);
  if (dice === 6) showSixBonus(actorColor);
  currentRoom.lastDice = dice;
  currentRoom.pendingRoll = {
    color: actorColor,
    value: dice,
    player: playerName,
    at: new Date().toISOString()
  };
  var message = playerName + "：掷出 " + dice + " 点，等待选择棋子";
  if (!movablePieceIndexes(actorColor).length) {
    currentRoom.pendingRoll = null;
    advanceTurn(actorColor);
    message = playerName + "：掷出 " + dice + " 点，没有可移动棋子，自动轮到下一位";
  }
  currentRoom.log.push(nowText() + " " + message);
  saveRoom(message, { color: actorColor, name: playerName }).catch(function (error) {
    alert(error.message);
  });
}

function advanceTurn(actorColor) {
  var before = currentRoom.turnColor;
  currentRoom.turnColor = nextTurnColor(actorColor);
  if (currentRoom.turnColor === activeColors()[0] && currentRoom.turnColor !== before) currentRoom.round += 1;
}

function movePiece(pieceIndex) {
  if (!currentRoom) return alert("请先创建或加入房间");
  if (animatingMove) return;
  var actorColor = currentActorColor();
  if (!actorColor) return alert("请先加入联机房间");
  if (!isMyTurnColor(actorColor)) {
    return alert("现在是 " + COLOR_NAMES[currentRoom.turnColor] + " 的回合");
  }
  if (!hasPendingRollFor(actorColor)) {
    return alert("请先掷骰子，再选择棋子。");
  }
  var dice = Number(currentRoom.pendingRoll.value);
  var playerName = actorNameFor(actorColor);
  var pieces = currentRoom.pieces[actorColor];
  var from = pieces[pieceIndex];
  if (!canMovePiece(actorColor, from)) {
    return alert("这枚棋子当前不能移动。");
  }
  var to = progressAfterDice(from, dice);
  var rawTo = from < 0 ? to : from + dice;
  var actionText = "";
  if (from < 0) {
    if (dice === 6) {
      actionText = "掷出 6，" + (pieceIndex + 1) + "号从基地起飞到停机坪";
    } else {
      actionText = "掷出 " + dice + "，" + (pieceIndex + 1) + "号仍在基地";
    }
  } else if (from === FINISH_PROGRESS) {
    actionText = "掷出 " + dice + "，" + (pieceIndex + 1) + "号已经到达终点";
  } else if (rawTo > FINISH_PROGRESS) {
    actionText = "掷出 " + dice + "，超过终点后折返，" + (pieceIndex + 1) + "号从 " + pieceText(from) + " 到 " + pieceText(to);
  } else {
    actionText = "掷出 " + dice + "，" + (pieceIndex + 1) + "号从 " + pieceText(from) + " 到 " + pieceText(to);
  }
  var jumpResult = maybeApplyFlightJump(actorColor, to);
  var landingBeforeJump = to;
  var flightLaneCaptured = [];
  if (jumpResult.jumped) {
    to = jumpResult.progress;
    actionText += "，触发直线飞跃到 " + pieceText(to);
  }
  var steps = buildDiceSteps(from, dice, landingBeforeJump);
  function finishMove() {
    pieces[pieceIndex] = to;
    if (to === FINISH_PROGRESS) {
      pieces[pieceIndex] = -2;
      actionText += "，到达终点，翻回基地";
      showWinBonus(actorColor);
    }
    if (flightLaneCaptured.length) {
      actionText += "，飞跃途中撞回 " + flightLaneCaptured.join("、");
      showCaptureBonus(actorColor);
    }
    var collisions = findCollisions(actorColor, pieceIndex, pieces[pieceIndex]);
    var captured = captureOpponents(actorColor, pieces[pieceIndex]);
    if (captured.length) {
      actionText += "，吃掉 " + captured.join("、") + "，对方回到基地";
      showCaptureBonus(actorColor);
    } else if (collisions.length) {
      actionText += "，与 " + collisions.join("、") + " 碰撞";
      showCollisionBonus(actorColor);
    }
    currentRoom.lastDice = dice;
    currentRoom.pendingRoll = null;
    if (dice === 6) {
      actionText += "，掷出 6，可再掷一次";
    } else {
      advanceTurn(actorColor);
    }
    var message = playerName + "：" + actionText;
    currentRoom.log.push(nowText() + " " + message);
    saveRoom(message, { color: actorColor, name: playerName }).catch(function (error) {
      alert(error.message);
    });
  }
  animateMove(actorColor, pieceIndex, steps, function () {
    if (!jumpResult.jumped) {
      finishMove();
      return;
    }
    pieces[pieceIndex] = landingBeforeJump;
    animateFlightJump(actorColor, pieceIndex, landingBeforeJump, to, function () {
      flightLaneCaptured = captureFlightLaneOpponents(actorColor, pieceIndex, landingBeforeJump, to);
      finishMove();
    });
  });
}

function resetRoom() {
  if (!currentRoom) return alert("请先创建或加入房间");
  if (!confirm("重置当前房间棋盘？玩家和房间规则会保留。")) return;
  var players = currentRoom.players;
  var mode = currentRoom.mode;
  var settings = currentRoom.settings;
  currentRoom = createInitialRoom(currentRoom.roomCode, mode, settings);
  currentRoom.players = mode === "single" ? createSinglePlayers() : players;
  currentRoom.log.push(nowText() + " 棋盘已重置。");
  saveRoom("重置房间 " + currentRoom.roomCode).catch(function (error) {
    alert(error.message);
  });
}

function resetLocalRoomView(statusText) {
  window.clearInterval(pollTimer);
  var mode = currentRoom ? currentRoom.mode : $("roomModeInput").value;
  currentPlayer = null;
  currentRoomRecord = null;
  localOnlyRoom = false;
  currentRoom = createInitialRoom(roomCode(), mode, {
    pieceCount: pieceCountFromInput(),
    canCapture: $("captureInput").checked,
    canFlightLaneCapture: $("flightLaneCaptureInput").checked
  });
  setStatus(statusText);
  renderRoom();
  refreshRoomList();
}

function leaveRoom() {
  if (!currentRoomRecord || !currentRoom) {
    resetLocalRoomView("已退出房间");
    return;
  }
  if (currentRoom.mode !== "online" || !currentPlayer) {
    resetLocalRoomView("已退出房间");
    return;
  }
  var leavingPlayer = currentPlayer;
  if (!currentRoom.players[leavingPlayer.color]) {
    removeStoredPlayer(currentRoom.roomCode);
    resetLocalRoomView("已退出房间");
    return;
  }
  delete currentRoom.players[leavingPlayer.color];
  currentRoom.turnOrder = (currentRoom.turnOrder || []).filter(function (color) {
    return color !== leavingPlayer.color;
  });
  removeStoredPlayer(currentRoom.roomCode);
  if (currentRoom.pendingRoll && currentRoom.pendingRoll.color === leavingPlayer.color) {
    currentRoom.pendingRoll = null;
  }
  var remaining = COLORS.filter(function (color) {
    return Boolean(currentRoom.players[color]);
  });
  remaining.forEach(function (color) {
    if (currentRoom.turnOrder.indexOf(color) < 0) currentRoom.turnOrder.push(color);
  });
  if (!remaining.length) {
    currentRoom.turnColor = "red";
  } else if (currentRoom.turnColor === leavingPlayer.color || !currentRoom.players[currentRoom.turnColor]) {
    currentRoom.turnColor = remaining[0];
  }
  var message = leavingPlayer.name + " 离开房间";
  currentRoom.log.push(nowText() + " " + message);
  currentPlayer = null;
  saveRoom(message, { color: leavingPlayer.color, name: leavingPlayer.name }).then(function () {
    resetLocalRoomView("已退出房间");
  }).catch(function (error) {
    alert(error.message);
  });
}

$("joinRoomBtn").onclick = joinRoom;
$("syncBtn").onclick = function () { loadRoom(false).catch(function (error) { alert(error.message); }); };
$("resetRoomBtn").onclick = resetRoom;
$("rollDiceBtn").onclick = rollDice;
$("leaveRoomBtn").onclick = leaveRoom;
$("refreshRoomsBtn").onclick = function () { refreshRoomList(); };
$("roomModeInput").onchange = function () {
  $("onlineJoinFields").style.display = $("roomModeInput").value === "single" ? "none" : "block";
};
$("roomsList").onclick = function (event) {
  var button = event.target.closest("[data-room-code]");
  if (!button) return;
  $("roomCodeInput").value = button.getAttribute("data-room-code");
  $("roomPasswordInput").focus();
};
$("orderPanel").onclick = function (event) {
  var button = event.target.closest("[data-order-action]");
  if (!button || button.disabled || !currentRoom || isOrderDecided()) return;
  var action = button.getAttribute("data-order-action");
  if (action === "dice") decideOrderByDice();
  if (action === "manual") decideOrderManually();
};
$("pieceControls").onclick = function (event) {
  var button = event.target.closest("[data-piece-index]");
  if (!button || button.disabled) return;
  movePiece(Number(button.getAttribute("data-piece-index")));
};

currentRoom = createInitialRoom("demo-room-01", "online", { pieceCount: 4, canCapture: true, canFlightLaneCapture: true });
renderRoom();
refreshRoomList();
